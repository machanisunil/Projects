import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { unregister } from './registerServiceWorker';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import allReducers from './reducers';
import { PersistGate } from 'redux-persist/integration/react';
import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import { loadProp } from './actions/app-action';
import { ThemeProvider } from 'styled-components';
import Theme from './Theme'
import reportWebVitals from './reportWebVitals';


const persistConfig = { key: 'root', storage };
const persistedReducer = persistReducer(persistConfig, allReducers);

const store = createStore(persistedReducer);
const persistor = persistStore(store);
export { store };

fetch('env.json')
  .then(r => r.json())
  .then(data => {
    store.dispatch(loadProp(data));
  });
const theme = new Theme();
ReactDOM.render(
  <Provider store={store}>
    <PersistGate loading={null} persistor={persistor}>
      <ThemeProvider theme={theme.themeObj}>
        <App />
      </ThemeProvider>
    </PersistGate>
  </Provider>,
  document.getElementById('root'),
);

unregister();
// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
