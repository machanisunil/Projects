/**
 * Auxulary compoenent to avoid to use unnecessary div/wrapper
 */
 const Aux = props => props.children;

 export { Aux };
 