// Theme default configuration
import Color from 'color';
const color = c => new Color(c);
class Theme {
  constructor(p, s) {
    this.themeObj = {
      primaryColor: p || '#e24b33',
      secondaryColor: s || '#FCB712',
      mixins: {
        darken: (c, v) =>
          color(c)
            .darken(v)
            .hex(),
        lighten: (c, v) =>
          color(c)
            .lighten(v)
            .hex(),
        isDark: (c = p) => {
          return color(c).isDark();
        },
        isLight: (c = s) => {
          return color(c).isLight();
        },
      },
    };
  }
}

export default Theme;