export default function (state = { breadcrumb: [], activeMenu: {} }, action) {
  switch (action.type) {
  case 'MENU_CLICK':
    return { ...state, activeMenu: action.activeMenu, breadcrumb: action.breadcrumb };
  case 'LOAD_PROP':
    return { ...state, prop: action.prop };
  default:
    return state;
  }
}