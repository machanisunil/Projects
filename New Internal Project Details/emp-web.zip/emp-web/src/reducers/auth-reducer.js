const initialState = {
  user: null,
};

const auth = (state = initialState, action) => {
  switch (action.type) {
    case 'LOGIN_SUCCESS':
      return { ...state, user: action.user };
    case 'LOGIN_FAILED':
      return { ...state, loginError: action.loginError };
    case 'LOGGED_OUT':
      return { ...state, user: action.user };
    default:
      return state;
  }
};
export default auth;
