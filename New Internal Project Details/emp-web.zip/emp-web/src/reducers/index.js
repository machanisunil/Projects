import { combineReducers } from 'redux';
import authReducer from './auth-reducer';
import utilReducer from './util-reducer';
import appReducer from './app-reducer';

const allReducers = combineReducers({
  auth: authReducer,
  util: utilReducer,
  app: appReducer,
});

export default allReducers;
