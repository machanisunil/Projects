export default function(state = { loading: false }, action) {
  switch (action.type) {
    case 'LOADING':
      return action.loading;
    default:
      return state;
  }
}
