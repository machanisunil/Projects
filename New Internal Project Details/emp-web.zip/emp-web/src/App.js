import React from 'react';
import './App.css';
import { Aux } from './HOC/Auxulary/Auxulary';
import {
  Switch,
  BrowserRouter
} from 'react-router-dom';
import { AuthRoutes } from './Components/Routers/index';

/**
check auth and unauth and navigate to role based dashboards.
 */
function App(props) {
  return (
    <Aux>
        <BrowserRouter>
            <Switch>
              <AuthRoutes {...props}/>
            </Switch>
        </BrowserRouter>
      </Aux>
  );
}

export default App;
