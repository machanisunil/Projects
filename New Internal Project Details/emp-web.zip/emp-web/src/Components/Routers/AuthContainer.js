import React from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import {Dashboard}  from '../Dashboard/index'

/**
To redirect or navigate to authorized components
 */
const AuthContainer = props => {
    return (
        <div id="content">
         <Switch>
			<Route exact path="/dashboard" component={Dashboard} />
			<Redirect to="/dashboard" />
		</Switch>
        </div>
      );
    }
  
  export { AuthContainer };