import React from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import { Login } from '../Login/index'

/**
To redirect or navigate to unauthorized components
 */
const UnAuthContainer = props => {
    return (
                <Switch>
                    <Route exact path="/login" component={Login} />
                    <Redirect to="/login" />
                </Switch>
    );
}

export { UnAuthContainer };