import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import { AuthContainer, UnAuthContainer } from './index';

/**
To redirect or navigate to authorized routes based on the user roles
 */
const AuthRoutes = props => {
	const user = localStorage.getItem('token')
	if (!user) return UnAuthRoutes(props);
	return (
		<Route
			render={prop =>
				user.token ? (
					<AuthContainer {...prop}   />
				) : (
						<Redirect to="/login" />
					)
			}
		/>

	);
};

/**
To redirect or navigate to unauthorized routes
 */
const UnAuthRoutes = props => {
	return (
		<Route
			
			render={prop => <UnAuthContainer {...prop}   />}
		/>
	);
};

export { AuthRoutes, UnAuthRoutes };
