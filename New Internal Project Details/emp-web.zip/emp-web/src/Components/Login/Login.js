import React from 'react';

/**
To display Login page and reset password page
 */
const Login = props => {
    return (
        <div>Login Page</div>
      );
    }
  
  export { Login };