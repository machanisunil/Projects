import React from 'react';

/**
To Define Dashboards for user
 */
const Dashboard = props => {
    return (
        <div>Dashboard Page</div>
      );
    }
  
  export { Dashboard };