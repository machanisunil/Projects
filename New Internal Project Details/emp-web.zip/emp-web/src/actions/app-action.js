export const menuClick = (activeMenu, breadcrumb) => {
  return {
    type: 'MENU_CLICK',
    activeMenu,
    breadcrumb,
  };
};

export const loadProp = props => {
  return {
    type: 'LOAD_PROP',
    prop: props,
  };
};
