export const loading = (loading) => {
  return {
    type: 'LOADING',
    loading:{loading:loading}
  };
};