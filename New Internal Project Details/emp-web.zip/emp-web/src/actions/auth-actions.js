export const loginSuccess = user => {
  return {
    type: 'LOGIN_SUCCESS',
    user,
  };
};

export const loginFailed = error => {
  return {
    type: 'LOGIN_FAILED',
    loginError: error,
  };
};
export const logOutSuccess = user => {
  return {
    type: 'LOGGED_OUT',
    user: null,
  };
};
