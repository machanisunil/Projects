var express = require('express');
var router = express.Router();
var shared=require('../database/db');
/* GET users listing. */
router.get('/getUsers',function(req,res){
    var q="select * from users";
    var con=shared.getConnection();

    con.connect(function(err,suc){
         if(err){
           res.send('db connection error');
         }
    })
 
   con.query(q,function(e,s){
      if(e){
        res.send(e);
      }else{
        res.send(s);
      }
   })
});

router.get('/deleteUser',function(req,res){
    var id=req.query.id;

    var q="delete from users where id="+id;
    var con=shared.getConnection();

    con.connect(function(err,suc){
         if(err){
           res.send('db connection error');
         }
    })
 
   con.query(q,function(e,s){
      if(e){
        res.send(e);
      }else{
        res.send(s);
      }
   })
});

router.post('/updateUser',function(req,res){
    var id=req.body.id;
    var pwd=req.body.pwd;
    var email=req.body.email;
    var phone=req.body.phone;
 
    var q="update users set pwd='"+pwd+"', email='"+email+"', phone='"+phone+"' where id="+id;
   
    var con=shared.getConnection();

    con.connect(function(err,suc){
         if(err){
           res.send('db connection error');
         }
    })
 
   con.query(q,function(e,s){
      if(e){
        res.send(e);
      }else{
        res.send(s);
      }
   })
    
});
router.post('/register',function(req,res){
   var u=req.body.uid;
   var p=req.body.pwd;
   var e=req.body.email;
   var m=req.body.phone;

   var con=shared.getConnection();

   con.connect(function(err,suc){
        if(err){
          res.send('db connection error');
        }
   })


  var q="insert into users(uid,pwd,email,phone) values('"+u +"','"+p+"','"+e+"','"+m+"')";

  con.query(q,function(e,s){
     if(e){
       res.send(e);
     }else{
       res.send(s);
     }
  })
})

router.post('/login',function(req,res){
    var un=req.body.uid;
    var pwd=req.body.pwd;
 

    var con=shared.getConnection();

   con.connect(function(err,suc){
        if(err){
          res.send('db connection error');
        }
   })

   var q="select * from users where uid='"+un+"' and pwd='" +pwd+"'";

  con.query(q,function(e,r){
     if(e){
       res.send(e);
     }else{
       res.send(r);
     }
  });


});



module.exports = router;
