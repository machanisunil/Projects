import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Header from './Header/Header';
import Footer from './Footer/Footer';
import Menu from './Menu/Menu';
import BeforeLogin from './BeforeLogin/BeforeLogin';
import {connect} from 'react-redux'
class App extends Component {
  render() {
    return (
      <div className="App">
         <Header />
          {
            this.props.isLoggedIn ? <Menu /> : <BeforeLogin />
          }
         <Footer />
      </div>
    );
  }
}

const mapStateToProps=(state)=>{
  return {
     'isLoggedIn':state.loginReducer.isLoggedIn     
  }
}

export default connect(mapStateToProps)(App);
