import "./Header.css";
import React from "react";

function template() {
  return (
    <div className="header">
       React Reduxt with Node
    </div>
  );
};

export default template;
