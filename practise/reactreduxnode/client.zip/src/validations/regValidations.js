const regValidations=(formData)=>{
    var errors={};
   if(!formData.uid){
      errors.uid="Please enter uid"
   }else{
       if(formData.uid.length < 5){
        errors.uid="Please enter min 5 chars"
       }
   }

   if(!formData.pwd){
       errors.pwd="Please enter pwd"
   }

   if(!formData.email){
    errors.email="Please enter email"
   }else{
       var regExp=/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
       if(!regExp.test(formData.email)){
        errors.email="Please enter valid email"
       }
   }

 if(!formData.phone){
     errors.phone="Please enter phone"
 }

   return errors;
}

export default regValidations;