const updateValidations=(formData)=>{
    var errors={};
  

   if(!formData.pwd){
       errors.pwd="Please enter pwd"
   }

   if(!formData.email){
    errors.email="Please enter email"
   }else{
       var regExp=/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
       if(!regExp.test(formData.email)){
        errors.email="Please enter valid email"
       }
   }

 if(!formData.phone){
     errors.phone="Please enter phone"
 }

   return errors;
}

export default updateValidations;