const loginValidations=(formData)=>{
     var errors={};
    if(!formData.uid){
       errors.uid="Please enter uid"
    }

    if(!formData.pwd){
        errors.pwd="Please enter pwd"
    }

    return errors;
}

export default loginValidations;