import React    from "react";
import template from "./BeforeLogin.jsx";
import ServerCall from '../services/ServerCall';
import store from '../store/store';
class BeforeLogin extends React.Component {
  constructor(){
    super();
    var isLoggedIn=window.sessionStorage.getItem('isLoggedIn');
    if(isLoggedIn){
      store.dispatch({
        'type':'LOGIN_SUCCESS',
        'payload':true
    })
    }else{
      window.location.href="#/"
    }
  }

 
  render() {
    return template.call(this);
  }
}

export default BeforeLogin;
