import rootReducer from '../reducers/rootReducer';
import {createStore,applyMiddleware} from 'redux';
import logger from 'redux-logger';
import thunk from 'redux-thunk';

import rootSaga from '../sagas/rootSaga';
import createSagaMiddleware from 'redux-saga';

const saga=createSagaMiddleware();

const store=createStore(rootReducer,applyMiddleware(logger,thunk,saga));
saga.run(rootSaga);

export default store;