import "./Menu.css";
import React from "react";
import Home from '../Home/Home';
import Users from '../Users/Users';
import EditUser from '../EditUser/EditUser';
import {HashRouter,Route} from 'react-router-dom'
function template() {
  return (
    <div className="menu">
         <HashRouter>
             <div>
                   <div className="tabs">
                      <a href="#/home">HOME</a>
                      <a href="#/users">USERS</a>
                      <a href="#/editUser">EDIT USERS</a>
                      <a onClick={this.fnLogin}>Logout</a>
                   </div>

                   <Route path="/" exact component={Home} />
                   <Route path="/home"  component={Home} />
                   <Route path="/users"  component={Users} />
                   <Route path="/editUser"  component={EditUser} />
              </div>
           </HashRouter>
    </div>
  );
};

export default template;
