import React    from "react";
import template from "./Menu.jsx";
import store from '../store/store';
class Menu extends React.Component {
  render() {
    return template.call(this);
  }

  fnLogin(){
    store.dispatch({
      'type':'LOGOUT'
    })
    window.location.href="#/"
  }
}

export default Menu;
