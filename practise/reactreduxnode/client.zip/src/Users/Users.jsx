import "./Users.css";
import React from "react";
import TableCom from '../TableCom/TableCom';
function template() {
  return (
    <div className="users">
      <h1 className='text-center'>Users</h1>
      <TableCom delete={this.delete} edit={this.edit} headers={this.state.h} data={this.state.data} keys={this.state.k} />
    </div>
  );
};

export default template;
