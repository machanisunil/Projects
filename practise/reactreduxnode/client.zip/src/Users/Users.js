import React    from "react";
import template from "./Users.jsx";
import ServerCall from '../services/ServerCall'
import { connect } from "react-redux";

class Users extends React.Component {
  constructor(){
    super();
    this.state={
      'h':['UId','PWD','EMAIL','PHONE'],
      'k':['uid','pwd','email','phone'],
      'data':[]
    }
    this.delete=this.delete.bind(this);
    this.edit=this.edit.bind(this);
  }
   componentWillMount(){
    this.fnGetUsers();
       
  }

 
  render() {
    return template.call(this);
  }

  edit(rowData){
  this.props.dispatch({
    'type':'USER_INFO',
    'payload':rowData
  })

  window.location.hash="#/editUser"
  }
  async delete(rowData){
  const res=await ServerCall.fnGetReq('users/deleteUser?id='+rowData.id);
  if(res.data  && res.data.affectedRows == 1){
    this.fnGetUsers();
    alert('delete');
  }else{
    alert('not deleted');
  }
  }

  async fnGetUsers(){
    const res=await ServerCall.fnGetReq('users/getUsers');
    this.setState({
      'data':res.data
    })
  }
}

const mdp=(d)=>{
  return {
    dispatch:d
  }
}

export default connect(null,mdp)(Users);
