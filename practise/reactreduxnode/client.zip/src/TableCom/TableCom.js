import React    from "react";
import template from "./TableCom.jsx";

class TableCom extends React.Component {
  render() {
    return template.call(this);
  }

  fnEdit(rowData){
  this.props.edit(rowData);
  }

  fnDelete(rowData){
    var confirm=window.confirm('r u sure');
    if(confirm){
      this.props.delete(rowData)
    }
  }
}

export default TableCom;
