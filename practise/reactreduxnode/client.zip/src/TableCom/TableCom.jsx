import "./TableCom.css";
import React from "react";

function template() {
  return (
    <div className="table-com">
      <div className="table-responsive">
        <table className='table table-bordered table-striped'>
          <tr>
            {
              this.props.headers.length > 0 && this.props.headers.map((v) => {
                return <th>{v}</th>
              })
            }

            <th>Edit</th>
            <th>Delete</th>
          </tr>
          {
            this.props.data.length > 0 && this.props.data.map((o) => {
              return <tr>
                {
                  this.props.keys.length > 0 && this.props.keys.map((k) => {
                    return <td>{o[k]}</td>
                  })
                }
                <td><input type="button" onClick={this.fnEdit.bind(this,o)} value='edit' className="btn btn-primary"/></td>
                <td><input type="button" onClick={this.fnDelete.bind(this,o)}value='delete' className="btn btn-primary"/></td>
              </tr>
            })
          }
        </table>
      </div>
    </div>
  );
};

export default template;
