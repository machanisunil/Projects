import TableCom from "./TableCom";
export default TableCom;
