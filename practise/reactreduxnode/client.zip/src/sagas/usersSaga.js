import {takeLatest,call,put} from 'redux-saga/effects';
import ServerCall from '../services/ServerCall';
function* updateUser(data){
    const res=yield call(ServerCall.fnPostReq,data.url,data.payload);
    if(res.data && res.data.affectedRows == 1){
        window.location.href="#/users";
    }else{
        window.alert('not updated');
    }
}


function* userSaga(){
    yield takeLatest('UPDATE_USER',updateUser);
}

export default userSaga;
