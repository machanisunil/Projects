import React    from "react";
import template from "./Register.jsx";
import {reduxForm} from 'redux-form';
import regValidations from '../validations/regValidations';
import ServerCall from '../services/ServerCall';

class Register extends React.Component {
  constructor(){
    super();
    this.state={
      'msg':''
    }
    this.fnRegister=this.fnRegister.bind(this);
  }
  render() {
    return template.call(this);
  }

  fnRegister(dataObj){
    ServerCall.fnPostReq('users/register',dataObj)
    .then((res)=>{
      if(res.data && res.data.affectedRows == 1){
         this.setState({
           'msg':'Success'
         })
         this.props.reset();
      }else{
        this.setState({
          'msg':'Error'
        })
      }
    })
    .catch(()=>{
      this.setState({
        'msg':'something went wrong'
      })
    })
  }
}


Register=reduxForm({
  'form':'regForm',
  'validate':regValidations
})(Register)
export default Register;
