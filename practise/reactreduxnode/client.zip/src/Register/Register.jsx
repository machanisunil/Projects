import "./Register.css";
import React from "react";
import {Field} from 'redux-form';
import textBox from '../reduxForms/textBox';

function template() {
  const {handleSubmit,invalid,reset,errors} = this.props;
  return (
    <div className="register container-fluid">
     <h3 className="text-center">REgister</h3>
      <form onSubmit={handleSubmit(this.fnRegister)}>
      <Field type="text" name="uid" lbl="User Name:" component={textBox} />
      <Field type="password" name="pwd" lbl="Password:" component={textBox} />
      <Field type="text" name="email" lbl="Email:" component={textBox} />
      <Field type="text" name="phone" lbl="Phone:" component={textBox} />
      <div className="row">
         <div className="offset-sm-5 col-sm-7">
          <input disabled={invalid} type="submit" value="Register" className="btn btn-primary" />
          <input onClick={reset} type="reset" value="Reset" className="btn btn-primary" />
          <a href="#/">to go to login</a>

         </div>
      </div>
      <div className="row">
        <div className="col-sm-12 text-center">
           <span>{this.state.msg}</span>
        </div>
      </div>
      </form>
    </div>
  );
};

export default template;
