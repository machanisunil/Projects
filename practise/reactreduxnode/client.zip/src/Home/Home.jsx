import "./Home.css";
import React from "react";

function template() {
  return (
    <div className="home">
      <h1 className="text-center">Welcome....my dear</h1>
    </div>
  );
};

export default template;
