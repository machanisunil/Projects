import {initUser} from '../utils/init';

const userReducer = (state=initUser,newData)=>{
        
     switch(newData.type){
         case 'USER_INFO':
           state={
               ...state,
               userInfo:newData.payload
           }
         break;
     }
     return state;
}
export default userReducer;

