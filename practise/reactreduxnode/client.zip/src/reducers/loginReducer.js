import {initLogin} from '../utils/init';

const loginReducer = (state=initLogin,newData)=>{
        
     switch(newData.type){
        case 'LOGOUT':
        window.sessionStorage.clear();
        state={
            ...state,
            isLoggedIn:false,
            msg:'',
        }
        break;
         case 'LOGIN_SUCCESS':
           state={
               ...state,
               isLoggedIn:newData.payload
           }
         break;
         case 'LOGIN_FAIL':
           state={
               ...state,
               msg:newData.payload
           }
         break;
     }
     return state;
}
export default loginReducer;

