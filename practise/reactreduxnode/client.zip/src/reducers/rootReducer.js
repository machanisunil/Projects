import loginReducer from './loginReducer';
import userReducer from './userReducer';
import {combineReducers} from 'redux';
import {reducer as form} from 'redux-form'
const rootReducer=combineReducers({loginReducer,userReducer,form});

export default rootReducer;