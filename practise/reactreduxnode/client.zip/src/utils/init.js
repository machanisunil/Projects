export const initLogin={
    isLoggedIn:false,
    msg:''
}

export const initUser={
    userInfo:{}
}

