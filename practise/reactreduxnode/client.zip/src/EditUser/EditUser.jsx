import "./EditUser.css";
import React from "react";
import {Field} from 'redux-form';
import textBox from '../reduxForms/textBox';
function template() {
  const {handleSubmit,invalid,reset,errors} = this.props;
  return (
    <div className="edit-user container-fluid">
      <h1 className="text-center">EditUser</h1>
      <form onSubmit={handleSubmit(this.fnUpdate)}>
      <Field type="password" name="pwd" lbl="Password:" component={textBox} />
      <Field type="text" name="email" lbl="Email:" component={textBox} />
      <Field type="text" name="phone" lbl="Phone:" component={textBox} />
      <div className="row">
         <div className="offset-sm-5 col-sm-7">
          <input disabled={invalid} type="submit" value="Update" className="btn btn-primary" />
         </div>
      </div>
      <div className="row">
        <div className="col-sm-12 text-center">
           <span>{this.state.msg}</span>
        </div>
      </div>
      </form>
    </div>
  );
};

export default template;
