import React    from "react";
import template from "./EditUser.jsx";
import {reduxForm} from 'redux-form'
import updateValidations from '../validations/updateUserValidations';
import {connect} from 'react-redux';
import store from '../store/store';
class EditUser extends React.Component {
  constructor(){
    super();
    this.state={
      'msg':''
    }
    this.fnUpdate=this.fnUpdate.bind(this);
  }
  render() {
    return template.call(this);
  }

  fnUpdate(values){
    store.dispatch({
      'type':'UPDATE_USER',
      'url':'users/updateUser',
      'payload':values
    })
  }
}

EditUser=reduxForm({
  'form':'editUser',
  validate:updateValidations
})(EditUser);

const msp=(state)=>{
  return {
    'initialValues':state.userReducer.userInfo,
    'msg':state.loginReducer.msg
  }
}
export default connect(msp)(EditUser);
