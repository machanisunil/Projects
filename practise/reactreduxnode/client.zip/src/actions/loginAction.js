import ServerCall from '../services/ServerCall';
const loginAction=(dataObj,url)=>{

  return (dispatch)=>{
    ServerCall.fnPostReq(url,dataObj)
    .then((res)=>{
        if(res.data && res.data.length == 1){
            dispatch({
                'type':'LOGIN_SUCCESS',
                'payload':true
            })
            window.sessionStorage.setItem('isLoggedIn',true);
        }else{
            dispatch({
                'type':'LOGIN_FAIL',
                'payload':"Please check entered uid or pwd"
            })
        }
    })
    .catch((res)=>{
        dispatch({
            'type':'LOGIN_FAIL',
            'payload':"Network error"
        })
    })
  }


  
}

export default loginAction;