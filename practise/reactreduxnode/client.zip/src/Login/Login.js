import React    from "react";
import template from "./Login.jsx";
import {reduxForm} from 'redux-form';
import loginValidations from '../validations/loginValidations';
import loginAction from '../actions/loginAction';
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
class Login extends React.Component {
  constructor(){
    super();
    this.fnLogin=this.fnLogin.bind(this);
  }
  render() {
    return template.call(this);
  }
  fnLogin(data){
    this.props.loginAction(data,'users/login')
  }
}


Login =reduxForm({
  'form':'loginForm',
  'validate':loginValidations
})(Login);

const msp=(state)=>{
  return {
    'message':state.loginReducer.msg
  }
}

const mdp=(dispatch)=>{
  return {
    'loginAction':bindActionCreators(loginAction,dispatch)
  }
}

export default connect(msp,mdp)(Login);
